import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Main {
    public static String LongestWord(String sen) {
        String[] stringArr =  sen.split(" ");
        sen = "";
        for(int i = 0; i < stringArr.length; i++){
            if(stringArr[i].length()>sen.length()){
                sen = stringArr[i];
            }
        }
        return sen;
    }
    public static void main (String[] args) {
        try {
            BufferedReader reader;
            if (args.length == 0) {
                reader = new BufferedReader(new InputStreamReader(System.in));
            }
            else {
                reader = new BufferedReader(new FileReader(args[0]));
            }
            System.out.println(LongestWord(reader.readLine()));
        } catch (IOException exception) {
            System.err.println(exception);
            System.exit(-1);
        }

    }

}